# There Are Optimizations

One of the platformers of all time

### Credits
# Me
